import {Component,Input,OnInit,Output,EventEmitter} from '@angular/core';
import { NgbActiveModal,NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup,FormControl,Validators } from '@angular/forms';
@Component({
  selector: 'app-editbook',
  templateUrl: './editbook.component.html',
  styleUrls:['./editbook.component.scss']
})
export class EditComponent implements OnInit {

@Input() bookData:any;
@Input() booktitle:string;
data:any;
bookGroup:FormGroup;
formatvalues:any = [
  {name: 'kindle', abbrev: 'kindle'},
  {name: 'eBook', abbrev: 'eBook'},
  {name: 'MSReader', abbrev: 'MSReader'}
]
genrevalues:any = [
  {name: 'Adventure', abbrev: 'Adventure'},
  {name: 'Fantasy', abbrev: 'Fantasy'},
  {name: 'Drama', abbrev: 'Drama'}
]
val:any;
genreval:any;
@Output() emitEditedBook = new EventEmitter<any>(this.data);

publicationDate:any;
  constructor(public modal:NgbActiveModal) {

  }
ngOnInit(){
  console.log(this.data);
  this.data = this.bookData;

  this.formatvalues.forEach(
    (x,i) => {
      if(this.booktitle == "Add"){
        this.val = null;
      } else {
        if(x.abbrev.toLocaleLowerCase() == this.data.format.toLocaleLowerCase()) {
          this.val = this.formatvalues[i];
        } else{
           return;
        }
      }
    }
  );
  this.genrevalues.forEach(
    (x,i) => {
      if(this.booktitle == "Add"){
        this.genreval = null;
      } else{
        if(x.abbrev.toLocaleLowerCase() == this.data.genre.toLocaleLowerCase()) {
          this.genreval = this.genrevalues[i];
        } else{
           return;
        }
      }
    }
  );
  let sample = new Date(this.data.publicationDate);
  this.publicationDate = {day: sample.getDate(),month:sample.getMonth() + 1,year: sample.getFullYear()};
   this.bookGroup = new FormGroup({
     title:new FormControl(this.data.title,Validators.required),
     author:new FormControl(this.data.author,Validators.required),
     isbn:new FormControl(this.data.isbn,Validators.required),
     publisher:new FormControl(this.data.publisher,Validators.required),
     publication:new FormControl(this.publicationDate,Validators.required),
     genre:new FormControl(this.genreval,Validators.required),
     format:new FormControl(this.val,Validators.required),
     price:new FormControl(this.data.price,Validators.required)
   });
   console.log(this.bookGroup);
}
fieldValue(fieldname){
  return this.bookGroup.controls[fieldname];
}
saveDetails(){

let x = this.fieldValue('publication').value;
const str = {
  title: this.fieldValue('title').value,
author: this.fieldValue('author').value,
isbn: this.fieldValue('isbn').value,
publisher: this.fieldValue('publisher').value,
 publicationDate: x.year + "-" + x.month + "-" + x.day,
 genre: this.fieldValue('genre').value.name,
 format: this.fieldValue('format').value.name,
 price: this.fieldValue('price').value
 }
 this.modal.close('Close click');
 console.log(str);
this.emitEditedBook.emit(str);
}

}
