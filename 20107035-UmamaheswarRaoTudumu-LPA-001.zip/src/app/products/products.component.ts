import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {ProductsService} from '../products.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { EditComponent} from '../modals/editbook/editbook.component';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  products: any = [];
  tempProducts: any = [];
  norecords:boolean = false;
  constructor(private prodservice: ProductsService, private modalService: NgbModal) { }

  ngOnInit() {
    this.prodservice.getBooks().subscribe(
      (data) => {
        console.log(data);
        this.tempProducts = data;
        this.products = data;
        this.products.forEach((e) => {
          e.checked = false;
        });
      },
      (error) => {
        console.log(error);
      }
    );
  }
  addBook(){
    const addbook = this.modalService.open(EditComponent, {ariaLabelledBy: 'modal-basic-title'});
    addbook.componentInstance.booktitle = 'Add';
    addbook.componentInstance.bookData = {};
    addbook.componentInstance.emitEditedBook.subscribe((x) => {
      console.log( 'x', x);
      addbook.result.then(
        (result) => {
        if (result) {
         this.addbook(x);
        } else {
          this.ngOnInit();
        }
      });
    },
    (error) => {
      console.log( 'error', error);
    });

  }
   editBook(index, id) {
    const editedbook = this.modalService.open(EditComponent, {ariaLabelledBy: 'modal-basic-title'});
    editedbook.componentInstance.booktitle = 'Edit';
    editedbook.componentInstance.bookData = this.products[index];
    editedbook.componentInstance.emitEditedBook.subscribe(
      (x) => {
      editedbook.result.then(
        (result) => {
        if(result) {
         this.updatebook(x, id);
        } else {
          this.ngOnInit();
        }
      });
    },
    (error) => {
      console.log( 'error' , error);
    });
  }

   updatebook( x, id) {
    this.prodservice.updateBook(x, id).subscribe(
      (data) => {
      this.ngOnInit();
   },
   (error) => {
     console.log(error);
   });
  }
  addbook(x) {
    this.prodservice.addBook(x).subscribe(
      (data) => {
      this.ngOnInit();
   },
   (error) => {
     console.log(error);
   });
  }
  deleteBook(id){
    this.prodservice.deleteBook(id).subscribe(
      (result) => {
        this.ngOnInit();
    },
    (error) => {
      console.error(error);
    });
  }
  filterBooks(event){
       const keytext: any = event;
       if (keytext) {
        const arr = this.tempProducts.filter(
          (data) => {
            return data.title.toLocaleLowerCase().indexOf(keytext.toLocaleLowerCase()) > -1;
           });
        if(arr.length == 0) {
            this.norecords = true;
            this.products = [];
           }else{
            this.products = arr;
            this.norecords = false;
           }

       } else {
         this.products = this.tempProducts;
         this.norecords = false;
       }
  }
  deleteAll(){
     this.products.forEach(element => {
       if (element.checked) {
        this.deleteBook(element.id);
       } else {
         return;
    }
     });
  }
}
