import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {


  constructor(private http:HttpClient) { }
  getBooks(){
    return this.http.get("http://localhost:3000/books/");
  }

  updateBook(x,id) {
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put("http://localhost:3000/books/"+ id, JSON.stringify(x) , {headers:headers});
  }
  addBook(data){
    let header = new HttpHeaders({'content-Type': 'application/json'});
    return this.http.post("http://localhost:3000/books/", JSON.stringify(data),{ headers : header });
  }
  deleteBook(id){
     return this.http.delete("http://localhost:3000/books/"+id);
  }
}
